import React from "react";

function Product(){
    return(
    <>
    <h3>Product</h3>
    </>
)}

export default Product;