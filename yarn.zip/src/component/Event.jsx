import React from "react";

function Event(){
    return(
    <>
    <h3>Event</h3>
    </>
)}

export default Event;