import React from "react";

function Notice(){
    return(
    <>
    <h3>Notice</h3>
    </>
)}

export default Notice;