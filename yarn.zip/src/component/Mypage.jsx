import React from "react";

function Mypage(){
    return(
    <>
    <h3>Mypage</h3>
    </>
)}

export default Mypage;