import React from "react";

function Cart(){
    return(
    <>
    <h3>Cart</h3>
    </>
)}

export default Cart;