import React from "react";

function Recommend(){
    return(
    <>
    <h3>Recommend</h3>
    </>
)}

export default Recommend;