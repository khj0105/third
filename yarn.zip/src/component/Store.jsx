import React from "react";

function Store(){
    return(
    <>
    <h3>store</h3>
    </>
)}

export default Store;