import React from "react";

function Search(){
    return(
    <>
    <h3>Search</h3>
    </>
)}

export default Search;